# Bitwarden Vault Deduper (static)

This is a single-page, client-side tool to review Bitwarden JSON exports for duplicates and generate a cleaned export.
It **does not** connect to Bitwarden or send data to a server; processing happens locally in your browser.

## Deploy (Vercel)
- Framework: **Other**
- Build command: *(none)*
- Output directory: `.`

## Safety
- Do **not** commit any Bitwarden export JSON files.
- `.gitignore` blocks common export patterns by default.

Generated: 2026-02-08 12:23:41
